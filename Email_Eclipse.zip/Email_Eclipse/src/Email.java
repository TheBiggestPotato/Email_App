
import java.io.*;
import java.util.Scanner;
import java.lang.String;
import java.lang.Exception;

public class Email {



    private void Inbox() throws Exception {

        System.out.println("Inbox-ul este gol.");
        Scanner scanner6 =new Scanner(System.in);
        System.out.println("\n1:Inapoi");
        int inapoi;
        inapoi = scanner6.nextInt();
        switch (inapoi){
            case 1: Menu();
            default:{
                System.out.println("Comanda gresita!");
                Inbox();
            }
        }

    }

    private void Spam() throws Exception {

        System.out.println("Spam-ul este gol.");
        Scanner scanner6 =new Scanner(System.in);
        System.out.println("\n1:Inapoi");
        int inapoi;
        inapoi = scanner6.nextInt();
        switch (inapoi){
            case 1: Menu();
        }
    }


    private void Compose() throws Exception {

        Scanner scanner7 = new Scanner(System.in);
        System.out.println("To: ");
        String to;
        to = scanner7.next();
        System.out.println("CC: ");
        String CC;
        CC = scanner7.next();
        System.out.println("Subject:  ");
        String Subject;
        Subject = scanner7.next();
        System.out.println("Continutul mailului:");
        PrintWriter compose = new PrintWriter("compose.txt");
        String txt;
        txt = scanner7.next();
        compose.println("To: ");
        compose.println(to);
        compose.println("CC: ");
        compose.println(CC);
        compose.println("Subject: ");
        compose.println(Subject);
        compose.println("Continut: ");
        compose.println(txt);
        compose.close();
        String exit = "exit";
        if (txt.equals(exit)) {
            Menu();
        } else System.out.println("\n1 Send \n2 Draft");
        int a = scanner7.nextInt();
        if (a == 1){
            System.out.println("Emailul a fost trimis.");
        } else if (a == 2){
            System.out.println("Textul a fot adugat in draft.");
        }
        Menu();
    }

        private void Draft() throws Exception {

            FileReader drfts = new FileReader("compose.txt");
            BufferedReader reader1 = new BufferedReader(drfts);
            String emailSalvat;
            while ((emailSalvat = reader1.readLine()) != null){
            System.out.println(emailSalvat);}
            System.out.println("\n1:Inapoi");
            Scanner scanner = new Scanner(System.in);
            int inapoi = scanner.nextInt();
                switch (inapoi){
                    case 1: Menu();
                }


        }

    public void Menu() throws Exception {

        System.out.println("\n1 Inbox \n2 Compose \n3 Drafts \n4 Spam \n5 Exit");
        Scanner scanner6 = new Scanner(System.in);
                int cifraMenu = scanner6.nextInt();
        switch (cifraMenu){

            case 1 : Inbox();
            break;
            case 2: Compose();
            break;
            case 3: Draft();
            break;
            case 4: Spam();
            break;
            case 5: System.exit(0);
            break;
            default: Menu();
        }
    }
}