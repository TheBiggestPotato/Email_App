
import java.lang.String;

public class Main {

    public static void main(String[] args) throws Exception {

        //obiecte pentru fiecare clasa
    Email menu = new Email();  //se ocupa de menu si functiile sale
    Register rgstr = new Register();
    Login lgin = new Login();
    //Identificarea sau inregistrarea user-ului si menu-ul
    rgstr.Email();
    lgin.Login_fnc();
    }

}
