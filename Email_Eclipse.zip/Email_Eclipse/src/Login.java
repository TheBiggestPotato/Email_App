
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Scanner;

public class Login {

    Email email = new Email();

    public void Login_fnc() throws Exception{

        String loginEmail;
        String loginPass;
        System.out.print("Email: ");
        Scanner scanner5 = new Scanner(System.in);
        loginEmail = scanner5.next();
        System.out.print("Password: ");
        loginPass = scanner5.next();
        FileReader file = new FileReader("out.txt");
        BufferedReader reader = new BufferedReader(file);
        String fileEmail = reader.readLine();
        String filePass = reader.readLine();
        if (loginEmail.equals(fileEmail) && loginPass.equals(filePass))
        {
            email.Menu();
        } else { System.out.println("Email sau parola gresita, reintroduceti datele!");
            Login_fnc();
        }
    }

}
