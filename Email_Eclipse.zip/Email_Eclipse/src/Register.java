import java.io.PrintWriter;
import java.util.Scanner;

public class Register {

    private String Nume;
    private String Prenume;
    private String Password;
    private String Password2;
    private String Departament;
    private String AlternativeMail;
    private String EmailFinal;
    private String Company = "Oracle";
    Login lgn = new Login();

    // Toate functiile de mai jos ajuta la inregistrarea user-ului pe platforma

    private String setDepartament() throws Exception {
        String Dep = null;
        Scanner scanner1 = new Scanner(System.in);
        System.out.print("Introduceti numele departamentului in care lucrati: ");
        Dep = scanner1.next();
        return Dep;
    }

    private String Parola(){

        Scanner scanner2 = new Scanner(System.in);
        Password = scanner2.next();
        return this.Password;
    }

    private String Parola_confirm(){

        Scanner scanner3 = new Scanner(System.in);
        this.Password2 = scanner3.next();
        return this.Password2;
    }

    private String RecoveryEmail(){

        System.out.print("Introduceti o adresa de email pentru confirmare si recuperare: ");
        Scanner scanner4 = new Scanner(System.in);
        this.AlternativeMail = scanner4.next();
        System.out.println("Confirmarea inregistratii a fost trimisa pe: " + this.AlternativeMail);
        return null;
    }

    public void Email() throws Exception
    {
        int lgRgstr;
        System.out.println("1.Login   2.Register");
        Scanner scanner0 =new Scanner(System.in);
        lgRgstr = scanner0.nextInt();
        switch (lgRgstr){

            case 1: lgn.Login_fnc();
            break;
            case 2: Register_fnc();
            break;
            default: Email();
        }


    }

    private void Register_fnc() throws Exception { //funcita de register propriu-zisa

        Scanner scanner = new Scanner(System.in);
        System.out.print("Introduceti numele: ");
        this.Nume = scanner.nextLine();
        System.out.print("Introduceti prenume: ");
        this.Prenume = scanner.nextLine();
        this.Departament = setDepartament();
        //concatenarea emailului final
        EmailFinal = Nume.toLowerCase() + "." + Prenume.toLowerCase() + "@" + Departament + "-" + Company + ".com";
        System.out.println("Adresa email a fost creata: " + EmailFinal);
        //parola
        System.out.print("Introduceti parola dorita: ");
        Parola();
        System.out.print("Reintroduceti parola: ");
        Parola_confirm();
        if (Password2.equals(Password)) {
            System.out.println("Parola a fost creata!");
        } else {
            while (!Password2.equals(Password)) {
                System.out.println("Parola nu se aseamana!");
                System.out.print("Reintroduceti parola: ");
                Parola_confirm();
                if (Password2.equals(Password)) {
                    System.out.println("Parola a fost creata!");
                    break;

                }
            }
        }

        PrintWriter outputStream = new PrintWriter("out.txt");
        outputStream.println(EmailFinal);
        outputStream.println(Password);
        outputStream.close();
        //email-ul pentru recovery/confirmare
        RecoveryEmail();
        System.out.println("Pentru a va loga apasati 1 sau 2 pentru a iesi din aplicatie");
        Scanner scanner7 = new Scanner(System.in);
        int loginConfirm = scanner7.nextInt();
        switch (loginConfirm){
            case 1: lgn.Login_fnc();
            case 2: System.exit(0);
        }
        }
    }
